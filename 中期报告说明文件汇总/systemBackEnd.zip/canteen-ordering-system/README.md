# canteen-ordering-system
毕设项目：食堂订餐系统
operate system: MacOS
IDE：IDEA
Java version：1.8
tomcat: 8,5.63

