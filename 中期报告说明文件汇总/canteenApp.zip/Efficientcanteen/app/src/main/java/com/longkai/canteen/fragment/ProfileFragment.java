package com.longkai.canteen.fragment;

import androidx.fragment.app.Fragment;

public class ProfileFragment extends BaseFragment {
}
