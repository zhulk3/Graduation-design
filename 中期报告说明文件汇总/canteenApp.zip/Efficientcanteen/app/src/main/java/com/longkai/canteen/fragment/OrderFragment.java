package com.longkai.canteen.fragment;

public class OrderFragment extends BaseFragment {
}
